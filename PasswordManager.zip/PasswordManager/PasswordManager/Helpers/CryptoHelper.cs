﻿using System;

namespace ConsoleApp1.Services
{
    public static class CryptoHelper
    {
        public static string Encode(string text)
        {
            return Convert.ToBase64String(System.Text.Encoding.UTF8.GetBytes(text));
        }

        public static string Decode(string encoded)
        {
            try
            {
                return System.Text.Encoding.UTF8.GetString(Convert.FromBase64String(encoded));
            }
            catch
            {
                return "Decoding error";
            }
        }
    }
}
