﻿using System;

namespace PasswordManagerApp.Models
{
    public class PasswordEntry
    {
        public string Name { get; set; }
        public string Login { get; set; }
        public string Password { get; set; }

        // Конструктор для создания нового пароля
        public PasswordEntry(string name, string login, string password)
        {
            Name = name;
            Login = login;
            Password = password;
        }
    }
}
