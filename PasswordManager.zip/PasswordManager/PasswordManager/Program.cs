﻿using System;
using PasswordManagerApp.Models;
using PasswordManagerApp.Services;

namespace PasswordManagerConsole
{
    class Program
    {
        private static PasswordManager passwordManager = new PasswordManager();

        static void Main(string[] args)
        {
            passwordManager.LoadPasswords();  // Загружаем пароли из файла при запуске программы
            while (true)
            {
                ShowMainMenu();
            }
        }

        private static void ShowMainMenu()
        {
            Console.Clear();
            Console.WriteLine("Password Manager");
            Console.WriteLine("1. Add Password");
            Console.WriteLine("2. View Passwords");
            Console.WriteLine("3. Search Password");
            Console.WriteLine("4. Delete Password");
            Console.WriteLine("5. Exit");
            Console.Write("Choose an option: ");
            var choice = Console.ReadLine();

            switch (choice)
            {
                case "1":
                    AddPassword();
                    break;
                case "2":
                    ViewPasswords();
                    break;
                case "3":
                    SearchPassword();
                    break;
                case "4":
                    DeletePassword();
                    break;
                case "5":
                    ExitApplication();
                    break;
                default:
                    Console.WriteLine("Invalid choice, please try again.");
                    Console.ReadKey();
                    break;
            }
        }

        private static void AddPassword()
        {
            Console.Clear();
            Console.WriteLine("Enter password name (or type 'back' to cancel):");
            string name = Console.ReadLine()?.Trim();
            if (name?.ToLower() == "back") return;

            Console.WriteLine("Enter login (or type 'back' to cancel):");
            string login = Console.ReadLine()?.Trim();
            if (login?.ToLower() == "back") return;

            Console.WriteLine("Enter password (or type 'back' to cancel):");
            string password = Console.ReadLine()?.Trim();
            if (password?.ToLower() == "back") return;

            if (string.IsNullOrEmpty(name) || string.IsNullOrEmpty(login) || string.IsNullOrEmpty(password))
            {
                Console.WriteLine("Invalid input. None of the fields can be empty.");
                return;
            }

            var entry = new PasswordEntry(name, login, password);
            passwordManager.Add(entry);
            Console.WriteLine("Password added successfully.");
            Console.ReadKey();
        }

        private static void ViewPasswords()
        {
            Console.Clear();
            var passwords = passwordManager.GetPasswords();
            if (passwords.Count == 0)
            {
                Console.WriteLine("No passwords stored yet.");
            }
            else
            {
                foreach (var entry in passwords)
                {
                    Console.WriteLine($"Name: {entry.Name}, Login: {entry.Login}, Password: {entry.Password}");
                }
            }
            Console.ReadKey();
        }

        private static void SearchPassword()
        {
            Console.Clear();
            Console.WriteLine("Enter search query (or type 'back' to cancel):");
            string query = Console.ReadLine()?.Trim();
            if (query?.ToLower() == "back") return;

            var results = passwordManager.Search(query);
            if (results.Count == 0)
            {
                Console.WriteLine("No passwords found matching the search.");
            }
            else
            {
                foreach (var entry in results)
                {
                    Console.WriteLine($"Name: {entry.Name}, Login: {entry.Login}, Password: {entry.Password}");
                }
            }
            Console.ReadKey();
        }

        private static void DeletePassword()
        {
            Console.Clear();
            Console.WriteLine("Enter the name of the password to delete (or type 'back' to cancel):");
            string name = Console.ReadLine()?.Trim();
            if (name?.ToLower() == "back") return;

            if (string.IsNullOrEmpty(name))
            {
                Console.WriteLine("Invalid input. Name cannot be empty.");
                Console.ReadKey();
                return;
            }

            int result = passwordManager.Delete(name);
            if (result > 0)
            {
                Console.WriteLine("Password deleted successfully.");
            }
            else
            {
                Console.WriteLine("No password found with that name.");
            }

            Console.ReadKey();
        }

        private static void ExitApplication()
        {
            Console.Clear();
            Console.WriteLine("Saving data and exiting...");
            passwordManager.SavePasswords();
            Environment.Exit(0);
        }
    }
}
