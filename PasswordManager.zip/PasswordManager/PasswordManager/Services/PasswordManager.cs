﻿using System;
using System.Collections.Generic;
using System.IO;
using PasswordManagerApp.Models;

namespace PasswordManagerApp.Services
{
    public class PasswordManager
    {
        private List<PasswordEntry> _passwords = new List<PasswordEntry>();
        private string _filePath = "passwords.txt";  // Путь к файлу для хранения паролей

        // Добавление нового пароля в список
        public void Add(PasswordEntry entry)
        {
            _passwords.Add(entry);
            SavePasswords();  // Сохранение пароля после добавления
        }

        // Получение всех паролей
        public List<PasswordEntry> GetPasswords()
        {
            return _passwords;
        }

        // Поиск паролей по запросу
        public List<PasswordEntry> Search(string query)
        {
            return _passwords.FindAll(p => p.Name.Contains(query, StringComparison.OrdinalIgnoreCase));
        }

        // Удаление пароля по имени
        public int Delete(string name)
        {
            var password = _passwords.Find(p => p.Name.Equals(name, StringComparison.OrdinalIgnoreCase));
            if (password != null)
            {
                _passwords.Remove(password);
                SavePasswords();  // Сохранение после удаления
                return 1;
            }
            return 0;
        }

        // Сохранение паролей в файл
        public void SavePasswords()
        {
            try
            {
                using (var writer = new StreamWriter(_filePath))
                {
                    foreach (var entry in _passwords)
                    {
                        writer.WriteLine($"{entry.Name}|{entry.Login}|{entry.Password}");
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error saving passwords: " + ex.Message);
            }
        }

        // Загрузка паролей из файла
        public void LoadPasswords()
        {
            if (File.Exists(_filePath))
            {
                var lines = File.ReadAllLines(_filePath);
                foreach (var line in lines)
                {
                    var parts = line.Split('|');
                    if (parts.Length == 3)
                    {
                        _passwords.Add(new PasswordEntry(parts[0], parts[1], parts[2]));
                    }
                }
            }
        }
    }
}
